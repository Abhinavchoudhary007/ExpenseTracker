from django.db import models

# Create your models here.
class Expense(models.Model):
    name = models.CharField(max_length=100)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    from datetime import date as dt_date
    date = models.DateField(default=dt_date.today)
    category = models.CharField(max_length=50)

    def __str__(self):
        return self.name
    