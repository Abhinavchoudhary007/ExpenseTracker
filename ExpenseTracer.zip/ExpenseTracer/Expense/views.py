from django.shortcuts import render, redirect
from .forms import ExpenseForm
from .models import Expense
from django.db import models
import datetime
# Create your views here.
def index(request):
    if request.method == 'POST':
        expense = ExpenseForm(request.POST)
        if expense.is_valid():
            expense.save()
            return redirect('index')
    expenses = Expense.objects.all()
    total_expenses = expenses.aggregate(total=models.Sum('amount'))
    if total_expenses['total'] is None:
        total_expenses['total'] = 0 
    #logic to calculate 365 days of expenses
    last_year = datetime.date.today() - datetime.timedelta(days=365) 
    data = Expense.objects.filter(date__gte=last_year)
    yearly_sum= data.aggregate(total=models.Sum('amount'))

    #logic to calculate 30 days of expenses
    last_month = datetime.date.today() - datetime.timedelta(days=30) 
    data = Expense.objects.filter(date__gte=last_month)
    monthly_sum= data.aggregate(total=models.Sum('amount'))

    #logic to calculate 7 days of expenses
    last_week = datetime.date.today() - datetime.timedelta(days=7) 
    data = Expense.objects.filter(date__gte=last_week)
    weekly_sum= data.aggregate(total=models.Sum('amount'))

    from django.db.models.functions import Cast
    from django.db.models import Sum, DateField

    # Calculate daily sums for past 30 days
    last_30_days = datetime.date.today() - datetime.timedelta(days=30)
    daily_sums = Expense.objects.filter(date__gte=last_30_days) \
        .annotate(date_only=Cast('date', DateField())) \
        .values('date_only') \
        .annotate(sum=Sum('amount')) \
        .order_by('date_only')

    # Calculate category sums for past 30 days
    category_sums = Expense.objects.filter(date__gte=last_30_days) \
        .values('category') \
        .annotate(sum=Sum('amount')) \
        .order_by('category')

    expense_form = ExpenseForm()
    return render(request, 'Expense/index.html', {
        'expense_form': expense_form,
        'expenses': expenses,
        'total_expenses': total_expenses['total'],
        'yearly_sum': yearly_sum['total'],
        'monthly_sum': monthly_sum['total'],
        'weekly_sum': weekly_sum['total'],
        'daily_sums': daily_sums,
        'category_sums': category_sums,
    })

from django.shortcuts import get_object_or_404

def edit(request,id):
    expense = Expense.objects.get(id=id)
    expense_form = ExpenseForm(instance=expense)
    if request.method == 'POST':
        form = ExpenseForm(request.POST, instance=expense)
        if form.is_valid():
            form.save()
            return redirect('index')
    return render(request, 'Expense/edit.html', {'expense_form': expense_form})
    
def delete(request, id):
    if request.method == 'POST' and 'delete' in request.POST:
        expense = Expense.objects.get(id=id)
        expense.delete()
    return redirect('index')

